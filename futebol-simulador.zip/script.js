// Dados iniciais dos times (salvos no localStorage se existirem)
let teams = JSON.parse(localStorage.getItem('fut_teams')) || [
    { id: 1, name: 'Dragões FC', power: 80 },
    { id: 2, name: 'Águias United', power: 75 },
    { id: 3, name: 'Falcões City', power: 85 },
    { id: 4, name: 'Leões da Bola', power: 70 }
];

function salvarDados() {
    localStorage.setItem('fut_teams', JSON.stringify(teams));
}

function mudarTela(telaId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
    document.getElementById(telaId).classList.remove('hidden');
    
    if (telaId === 'friendly-menu') carregarSeLEtoresTimes();
    if (telaId === 'edit-menu') carregarSeletorEdicao();
}

function carregarSeLEtoresTimes() {
    const homeSelect = document.getElementById('home-team');
    const awaySelect = document.getElementById('away-team');
    homeSelect.innerHTML = '';
    awaySelect.innerHTML = '';

    teams.forEach(t => {
        homeSelect.innerHTML += `<option value="${t.id}">${t.name} (Força: ${t.power})</option>`;
        awaySelect.innerHTML += `<option value="${t.id}">${t.name} (Força: ${t.power})</option>`;
    });
    if(teams.length > 1) awaySelect.selectedIndex = 1;
}

function carregarSeletorEdicao() {
    const editSelect = document.getElementById('edit-team-select');
    editSelect.innerHTML = '';
    teams.forEach(t => {
        editSelect.innerHTML += `<option value="${t.id}">${t.name}</option>`;
    });
    carregarDadosEdicao();
}

function carregarDadosEdicao() {
    const id = document.getElementById('edit-team-select').value;
    const team = teams.find(t => t.id == id);
    if (team) {
        document.getElementById('edit-name').value = team.name;
        document.getElementById('edit-power').value = team.power;
    }
}

function salvarEdicao() {
    const id = document.getElementById('edit-team-select').value;
    const team = teams.find(t => t.id == id);
    if (team) {
        team.name = document.getElementById('edit-name').value;
        team.power = parseInt(document.getElementById('edit-power').value);
        salvarDados();
        alert('Time atualizado com sucesso!');
        carregarSeletorEdicao();
    }
}

// Simulação da Partida
function iniciarPartida() {
    const homeId = document.getElementById('home-team').value;
    const awayId = document.getElementById('away-team').value;

    if (homeId === awayId) {
        alert('Escolha times diferentes para o amistoso!');
        return;
    }

    const homeTeam = teams.find(t => t.id == homeId);
    const awayTeam = teams.find(t => t.id == awayId);

    mudarTela('match-screen');
    document.getElementById('back-to-menu').classList.add('hidden');
    
    let goalsHome = 0;
    let goalsAway = 0;
    let minuto = 0;
    
    const commentary = document.getElementById('match-commentary');
    commentary.innerHTML = `Apita o árbitro! Começa a partida entre ${homeTeam.name} e ${awayTeam.name}.<br>`;
    
    const ball = document.getElementById('ball');
    
    let intervalo = setInterval(() => {
        minuto += 15;
        document.getElementById('score-home').innerText = `${homeTeam.name} ${goalsHome}`;
        document.getElementById('score-away').innerText = `${goalsAway} ${awayTeam.name}`;

        // Simples lógica de evento baseada na força
        let chance = Math.random() * 100;
        if (chance < homeTeam.power / (homeTeam.power + awayTeam.power) * 100) {
            ball.style.left = '300px';
            if (Math.random() < 0.4) {
                goalsHome++;
                commentary.innerHTML += `⚽ <b>GOL!</b> do ${homeTeam.name} aos ${minuto}min!<br>`;
            } else {
                commentary.innerHTML += `_{min}min: ${homeTeam.name} pressiona, mas perde a chance.<br>`;
            }
        } else {
            ball.style.left = '50px';
            if (Math.random() < 0.4) {
                goalsAway++;
                commentary.innerHTML += `⚽ <b>GOL!</b> do ${awayTeam.name} aos ${minuto}min!<br>`;
            } else {
                commentary.innerHTML += `${minuto}min: ${awayTeam.name} avança com perigo.<br>`;
            }
        }
        commentary.scrollTop = commentary.scrollHeight;

        if (minuto >= 90) {
            clearInterval(intervalo);
            commentary.innerHTML += `<b>Fim de jogo!</b> Placar final: ${homeTeam.name} ${goalsHome} x ${goalsAway} ${awayTeam.name}`;
            document.getElementById('back-to-menu').classList.remove('hidden');
        }
    }, 1500);
}
